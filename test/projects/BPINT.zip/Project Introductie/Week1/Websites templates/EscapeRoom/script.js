const passw = ["Hallo", "Christopher", "Is", "Super", "Cool", "hfsdhfahusdhusd"];
function inputCheck(type) {
    input = document.getElementById("input"+type);
    if (passw[type-1] == input.value) {
        input.style.backgroundColor = "green";
    }
    else {
        input.style.backgroundColor = "red";
    }
}

