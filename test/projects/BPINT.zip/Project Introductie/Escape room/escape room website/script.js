let passw = [];
function loadpassw() {
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
        passw = JSON.parse(this.responseText);
    }
    xhttp.open("GET", "passwords.txt", true);
    xhttp.send();
}

// checks if input matches password and colors input box accordingly
function color_check(c_type){
    input = document.getElementById("input"+c_type);
    if (passw[c_type-1] == input.value) {
        input.style.backgroundColor = "green";
    }
    else {
        input.style.backgroundColor = "red";
    }
}

// shows final key if all inputs are correct
function key_check(k_allCorrect) {
    const finalKey = document.getElementById("finalKey");
    if (k_allCorrect) {
        finalKey.style.display = "block";
    } else {
        finalKey.style.display = "none";
    }
}

// checks if all inputs are correct and shows final key if so
function all_check() {
    if (!passw.length) return;
    let allCorrect = true;
    for (let i = 1; i <= passw.length; i++) {
        const currentInput = document.getElementById("input" + i);
        if (currentInput.value !== passw[i - 1]) {
            allCorrect = false;
        }
    }
    key_check(allCorrect)
}

function main(type) {
    color_check(type)
    all_check()
}

// reads passwords from text file when page is loaded
document.addEventListener("DOMContentLoaded", loadpassw);
// cancels right click menu
document.oncontextmenu = function() {return false;}

