from random import randint, choice

def insert_new_dna(dna, new_base, location_new_base, remove = 0):
    return dna[:location_new_base] + new_base + dna[location_new_base + remove:]

#voert een base in de dna streng
def insert_dna(i_dna):
    new_base = input("Wat is het nieuwe base(n)")
    location_new_base = input('Wat is het locatie van de base? Type "x" voor een willekeurige plek. ')
    if location_new_base == "x" or location_new_base == "X":
        random_nmr = randint(0,len(i_dna))
        dna_new = insert_new_dna(i_dna, new_base, random_nmr)
    else:
        dna_new = insert_new_dna(i_dna, new_base, int(location_new_base))
    return dna_new

def keer_om(k_dna):
    return #maak af

#het programma verandert 1 base op een willekeurige plaats in een andere base. 
def muteren(m_dna):
    bases = "ACGT"
    random_nmr = randint(0,len(m_dna)-1)
    random_base = choice(bases)

    while random_base == m_dna[random_nmr]:
        random_nmr = randint(0,len(m_dna)-1)
    m_dna = insert_new_dna(m_dna, random_base, random_nmr, 1)
    
    return m_dna

#het programma geeft de complementaire sequentie
def complementaire(c_dna):
    complementaire_base = ""
    for i in c_dna:
        if i == "A":
            complementaire_base += "T"
        elif i == "T":
            complementaire_base += "A"
        elif i == "C":
            complementaire_base += "G"
        elif i == "G":
            complementaire_base += "C"
    return complementaire_base
        

def main():
    dna = input("Voer een DNA sequentie in. ")
    keuze_menu = input("Keuzemenu\n1. insertie toevoegen\n2. omklappen.\n3. willekeurige base muteren\n4. complementaire sequentie tonen\n5. stoppen ")
    while keuze_menu != "5":
        
        if keuze_menu == "1":
            dna = insert_dna(dna)
        elif keuze_menu == "2":
            dna = keer_om(dna)
        elif keuze_menu == "3":
            dna = muteren(dna)
        elif keuze_menu == "4":
            dna = complementaire(dna)
            
        print(dna)
        keuze_menu = input("Keuzemenu\n1. insertie toevoegen\n2. omklappen.\n3. willekeurige base muteren\n4. complementaire sequentie tonen\n5. stoppen ")
        
main()
