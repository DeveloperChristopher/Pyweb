file_path = 'escaperoomOplossingBestandSleutel.txt'
os.startfile(file_path)
