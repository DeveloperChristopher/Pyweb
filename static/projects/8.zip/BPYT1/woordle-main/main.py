def scores_bekijken():
    pass


def woord_toevoegen():
    pass


def naam_check(nc_naam):
    return nc_naam


def spelen():
    naam = naam_check(input("geef je naam op\n").lower())
    print(f"Welkom bij woordle, {naam}! Je moet het verborgen woord raden."
          "\nVoer een zes letter woord in om het woord te raden."
          "\nWanneer je een woord raadt krijg je in de regel eronder een +, - of * te zien."
          "\nEen + betekent dat die letter goed is en op de juiste plek staat."
          "\nEen * betekent dat die letter in het woord zit maar niet op de juiste plek staat."
          "\nEen - betekent dat die letter niet in het woord zit."
          "\nJe hebt 6 pogingen om het 6-letter woord te raden, veel succes!")


def keuzemenu():
    print("\nOpties:\n\t1. Woordle spelen\n\t2. Woord toevoegen\n\t3. Scores bekijken\n\t4. Programma sluiten\n")


def main():
    keuze = 0
    print("Welkom bij woordle!")
    keuzemenu()
    while keuze != "4":
        keuze = input("Voer een keuze in:\n")
        if keuze == "1":
            spelen()
            keuzemenu()
        elif keuze == "2":
            woord_toevoegen()
            keuzemenu()
        elif keuze == "3":
            scores_bekijken()
            keuzemenu()

main()